# Building the Docker Image

To build the Docker image simply run the `build` command and provide the tag `bmuschko/nodejs-read-config:1.0.0`.

```
docker build -t bmuschko/nodejs-read-config:1.0.0 .
```